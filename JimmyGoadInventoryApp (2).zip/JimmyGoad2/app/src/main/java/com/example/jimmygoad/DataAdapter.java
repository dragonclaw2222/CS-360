package com.example.jimmygoad;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class DataAdapter extends RecyclerView.Adapter<DataAdapter.ViewHolder> {
    private List<DataItem> dataList;
    private Context context;

    public DataAdapter(List<DataItem> dataList, Context context) {
        this.dataList = dataList;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_data, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        DataItem dataItem = dataList.get(position);
        holder.dataTextView.setText(dataItem.getTitle());
        holder.dateTextView.setText(dataItem.getDate()); // Bind the date

        holder.deleteButton.setOnClickListener(v -> {
            // Handle delete action directly
            dataList.remove(position);
            notifyItemRemoved(position);
        });
    }

    @Override
    public int getItemCount() {
        return dataList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView dataTextView;
        TextView dateTextView; // Add a reference for date
        Button deleteButton;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            dataTextView = itemView.findViewById(R.id.data_text_view);
            dateTextView = itemView.findViewById(R.id.date_text_view); // Initialize date TextView
            deleteButton = itemView.findViewById(R.id.delete_button);
        }
    }
}