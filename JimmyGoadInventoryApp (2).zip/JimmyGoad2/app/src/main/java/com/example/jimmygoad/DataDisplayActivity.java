package com.example.jimmygoad;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;
import android.widget.LinearLayout;

public class DataDisplayActivity extends AppCompatActivity {
    private List<DataItem> dataItemList;
    private DataAdapter dataAdapter;
    private RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_display);

        recyclerView = findViewById(R.id.data_recycler_view);
        dataItemList = new ArrayList<>();

        // Sample data
        dataItemList.add(new DataItem("Item 1", "Date 1"));
        dataItemList.add(new DataItem("Item 2", "Date 2"));

        dataAdapter = new DataAdapter(dataItemList, this);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(dataAdapter);

        Button logoutButton = findViewById(R.id.logout_button);
        logoutButton.setOnClickListener(v -> {
            Intent intent = new Intent(DataDisplayActivity.this, LoginActivity.class);
            startActivity(intent);
            finish(); // Close current activity
        });

        // Manage permissions button listener
        Button managePermissionsButton = findViewById(R.id.manage_permissions_button);
        managePermissionsButton.setOnClickListener(v -> openAppSettings());

        // Add data button listener
        Button addDataButton = findViewById(R.id.add_data_button);
        addDataButton.setOnClickListener(v -> showAddDataDialog());
    }

    private void showAddDataDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Add Data Item");

        // Set up the input fields
        final EditText inputItem = new EditText(this);
        inputItem.setHint("Item Title");
        final EditText inputDate = new EditText(this);
        inputDate.setHint("Item Date");

        // Set the input fields in a vertical layout
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.addView(inputItem);
        layout.addView(inputDate);
        builder.setView(layout);

        // Set up the buttons
        builder.setPositiveButton("Add", (dialog, which) -> {
            String itemTitle = inputItem.getText().toString();
            String itemDate = inputDate.getText().toString();

            if (!itemTitle.isEmpty() && !itemDate.isEmpty()) {
                dataItemList.add(new DataItem(itemTitle, itemDate));
                dataAdapter.notifyItemInserted(dataItemList.size() - 1);
                Toast.makeText(DataDisplayActivity.this, "Data item added", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(DataDisplayActivity.this, "Please enter both fields", Toast.LENGTH_SHORT).show();
            }
        });

        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());

        builder.show();
    }

    private void openAppSettings() {
        Intent intent = new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        intent.setData(Uri.parse("package:" + getPackageName()));
        startActivity(intent);
    }
}