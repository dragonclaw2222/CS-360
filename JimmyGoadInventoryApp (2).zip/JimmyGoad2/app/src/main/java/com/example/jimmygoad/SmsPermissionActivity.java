package com.example.jimmygoad;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SmsPermissionActivity extends AppCompatActivity {
    private static final int SMS_PERMISSION_CODE = 101;
    private TextView responseText;
    private Button requestPermissionButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_permission);

        responseText = findViewById(R.id.response_text);
        requestPermissionButton = findViewById(R.id.request_permission_button);

        // Check if permission has already been granted
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            responseText.setText("Permission granted. You will receive SMS notifications.");
            goToDataDisplayActivity(); // Navigate immediately if permission is granted
        }

        requestPermissionButton.setOnClickListener(v -> checkSmsPermission());
    }

    private void checkSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        SharedPreferences prefs = getSharedPreferences("app_prefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();

        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                responseText.setText("Permission granted. You will receive SMS notifications.");
                editor.putBoolean("sms_permission_granted", true);
            } else {
                responseText.setText("Permission denied. You will not receive SMS notifications.");
                editor.putBoolean("sms_permission_granted", false);
            }
            editor.apply();
            goToDataDisplayActivity(); // Navigate to DataDisplayActivity regardless of the permission status
        }
    }

    private void goToDataDisplayActivity() {
        Intent intent = new Intent(SmsPermissionActivity.this, DataDisplayActivity.class);
        startActivity(intent);
        finish(); // Close this activity
    }
}